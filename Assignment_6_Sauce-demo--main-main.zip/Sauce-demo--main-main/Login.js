/// <reference types="cypress" />

import { loginPageElements } from "../../../PageObjects/PageActions/LoginPageActions";

const Login_Elements = new loginPageElements();

describe('Page Object Model', function () {
  it('Login Page', function () {
    cy.visit('/');
    Login_Elements.username('standard_user');
    Login_Elements.password('secret_sauce');
    Login_Elements.LoginButton();

    // Add an assertion to confirm login success
    cy.url().should('include', '/inventory.html');
  });
});
